function loadCart() {
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    const cartContainer = document.getElementById("cartTable");
    const totalDisplay = document.getElementById("totalPrice");

    cartContainer.innerHTML = "";

    if (cart.length === 0) {
        cartContainer.innerHTML = `<p style="text-align:center; font-size:1.1rem; color: #6b7280;">Your cart is empty.</p>`;
        totalDisplay.textContent = "Total: $0.00";
        return;
    }

    let total = 0;

    cart.forEach((book, index) => {
        total += parseFloat(book.price);

        const item = document.createElement("div");
        item.className = "cart-item";
        item.innerHTML = `
            <div class="item-info">
                <p class="title">${book.title}</p>
                <p>by ${book.author}</p>
                <p>Genre: ${book.genre}</p>
                <p>Price: $${parseFloat(book.price).toFixed(2)}</p>
            </div>
            <button class="remove-btn" onclick="removeFromCart(${index})">Remove</button>
        `;
        cartContainer.appendChild(item);
    });

    totalDisplay.textContent = `Total: $${total.toFixed(2)}`;
}

function removeFromCart(index) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.splice(index, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    loadCart();
}

// Initialize cart when cart.html is loaded
if (window.location.pathname.includes("cart.html")) {
    document.addEventListener("DOMContentLoaded", loadCart);
}
