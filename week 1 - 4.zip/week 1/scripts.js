document.addEventListener("DOMContentLoaded", function () {
    let users = JSON.parse(localStorage.getItem("users")) || [];
    let loggedInUser = localStorage.getItem("loggedInUser");
  
    let authLinks = document.querySelectorAll(".auth");
    let logoutLink = document.getElementById("logoutLink");
  
    // Show/Hide Login & Logout Links based on login status
    if (loggedInUser) {
      authLinks.forEach(link => link.style.display = "none");
      if (logoutLink) logoutLink.style.display = "block";
    } else {
      authLinks.forEach(link => link.style.display = "block");
      if (logoutLink) logoutLink.style.display = "none";
    }
  
    // Handle Login Form Submission
    let loginForm = document.getElementById("loginForm");
    if (loginForm) {
      loginForm.addEventListener("submit", function (event) {
        event.preventDefault();
        loginUser();
      });
    }
  
    // Handle Register Form Submission
    let registerForm = document.getElementById("registerForm");
    if (registerForm) {
      registerForm.addEventListener("submit", function (event) {
        event.preventDefault();
        registerUser();
      });
    }
  
    // Handle Forgot Password Form Submission
    let forgotPasswordForm = document.getElementById("forgotPasswordForm");
    if (forgotPasswordForm) {
      forgotPasswordForm.addEventListener("submit", function (event) {
        event.preventDefault();
        forgotPassword();
      });
    }
  
    // Handle Logout Click
    if (logoutLink) {
      logoutLink.addEventListener("click", function (event) {
        event.preventDefault();
        logoutUser();
      });
    }
  });
  
  // Function to handle user registration
  function registerUser() {
    let username = document.getElementById("username").value.trim();
    let email = document.getElementById("email").value.trim();
    let password = document.getElementById("password").value;
    let confirmPassword = document.getElementById("confirmPassword").value;
    let users = JSON.parse(localStorage.getItem("users")) || [];
  
    // Validation Checks
    if (!username || !email || !password) {
      alert("All fields are required!");
      return;
    }
  
    if (password !== confirmPassword) {
      alert("Passwords do not match!");
      return;
    }
  
    // Check for duplicate username or email
    if (users.some(user => user.username === username)) {
      alert("Username already taken. Please choose another.");
      return;
    }
    if (users.some(user => user.email === email)) {
      alert("This email is already registered. Try logging in.");
      return;
    }
  
    // Store new user with email
    users.push({ username, email, password });
    localStorage.setItem("users", JSON.stringify(users));
  
    alert("Registration successful! You can now log in.");
    window.location.href = "login.html";
  }
  
  // Function to handle user login
  function loginUser() {
    let username = document.getElementById("loginUsername").value;
    let password = document.getElementById("loginPassword").value;
    let users = JSON.parse(localStorage.getItem("users")) || [];
    let user = users.find(u => u.username === username && u.password === password);
  
    if (user) {
      localStorage.setItem("loggedInUser", username);
      alert(`Welcome, ${username}! Login successful.`);
      // Refresh header and navigation frames to update UI dynamically
      if (parent.frames["headerFrame"]) parent.frames["headerFrame"].location.reload();
      if (parent.frames["navFrame"]) parent.frames["navFrame"].location.reload();
  
      // Redirect content frame to the main page
      if (parent.frames["contentFrame"]) {
        parent.frames["contentFrame"].location.href = "content.html";
      } else {
        window.location.href = "content.html"; // Fallback for non-frame users
      }
    } else {
      alert("Invalid username or password");
    }
  }
  
  // Function to handle forgot password
  function forgotPassword() {
    let email = document.getElementById("email").value.trim();
    let users = JSON.parse(localStorage.getItem("users")) || [];
    let user = users.find(u => u.email === email);
  
    if (!user) {
      alert("Email not found! Please register or check your email.");
      return;
    }
  
    // Show password fields when email is verified
    document.getElementById("passwordContainer").style.display = "flex";
    document.getElementById("confirmPasswordContainer").style.display = "flex";
  
    let newPassword = document.getElementById("newPassword").value;
    let confirmPassword = document.getElementById("confirmPassword").value;
  
    if (!newPassword || !confirmPassword) {
      return; // Wait until user fills both fields
    }
  
    if (newPassword !== confirmPassword) {
      alert("Passwords do not match! Try again.");
      return;
    }
  
    // Update password in localStorage
    user.password = newPassword;
    localStorage.setItem("users", JSON.stringify(users));
  
    alert("Password reset successful! You can now log in with your new password.");
    window.location.href = "login.html";
  }
  
  // Function to toggle password visibility
  function togglePassword(inputId) {
    let inputField = document.getElementById(inputId);
    if (inputField.type === "password") {
      inputField.type = "text";
    } else {
      inputField.type = "password";
    }
  }
  
  // Function to handle user logout
  function logoutUser() {
    localStorage.removeItem("loggedInUser");
    alert("Logged out successfully!");
    // Refresh header and navigation frames to reflect logout state
    if (parent.frames["headerFrame"]) parent.frames["headerFrame"].location.reload();
    if (parent.frames["navFrame"]) parent.frames["navFrame"].location.reload();
  
    // Redirect content frame back to login page
    if (parent.frames["contentFrame"]) {
      parent.frames["contentFrame"].location.href = "login.html";
    } else {
      window.location.href = "login.html"; // Fallback for non-frame users
    }
  }
  