package com.jpmtechnologies;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaUpdate;

import com.jpmtechnologies.model.Student;
public class Test 
{
	public static void main(String[] args) 
	{
		Configuration cfg=new Configuration();
		cfg.configure();

		SessionFactory sf = cfg.buildSessionFactory();
		Session ses=sf.openSession();
		
		Transaction tx=ses.beginTransaction();//insert/update/delete operations only (Non-select)
		Student st=new Student();
		
		st.setStdId(101);
		st.setStdName("Prasad");
		st.setStdFee(3000);
		st.setAge(25);
		
		ses.save(st);//Inserting the record
		
		tx.commit();//Saving the record in database
		
		ses.close();
		
		System.out.println("Record inserted successfully...!!");
	}
}