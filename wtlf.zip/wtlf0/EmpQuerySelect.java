package com.jpmtechnologies;


import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Expression;

public class EmpQuerySelect
{
    @SuppressWarnings("rawtypes")
	public static void main(String args[])
    {
        try {
            SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
            Session session = sessionFactory.openSession();

            // Displays all employees' first and last names, who have a account in gmail.

            Query query = session.createQuery(" select eb.fname, eb.lname " +
                                              " from EmpBean eb " +
                                              " where eb.email like '%gmail.com'");
            
            //select e.firstname, e.lastname from employee e where e.email like '%gmail.com';
            
            
            Iterator itr = query.iterate();
            while(itr.hasNext())
            {
                Object[] row = (Object[])itr.next();
                String fname = (String)row[0];
                String lname = (String)row[1];
                System.out.println(fname + "\t" + lname);
            }

            // Displays all details of employees JPM and Technologies, whose employee ids are between 101 and 200.

            System.out.println("\n\n\n");

            Criteria criteria = session.createCriteria(EmpBean.class);
            criteria = criteria.add(Expression.between("id", new Long(101), new Long(200)));
            criteria = criteria.add(Expression.in("fname", new String[] {"JPM", "Technologies"}));

            List list = criteria.list();
            for(int x = 0; x < list.size(); x++)
            {
                EmpBean emp = (EmpBean)list.get(x);
                System.out.println(emp.getId()     + "\t" + emp.getFname() + "\t" +
                                    emp.getLname() + "\t" + emp.getEmail());
            }


			System.out.println("\n\n\n using native sql for criteria ");
			Criteria criteria1 = session.createCriteria(EmpBean.class);
			criteria1 = criteria1.add(Expression.sql("email like '%gmail.com'"));
			List l1 = criteria1.list();
			for(int x = 0; x < l1.size(); x++)
			{
				EmpBean emp = (EmpBean)l1.get(x);
                System.out.println(emp.getId() + "\t" + emp.getFname() + "\t" +
                                   emp.getLname() + "\t" + emp.getEmail());
			}
            session.close();
        }
        catch (HibernateException e)
        {
            e.printStackTrace();
        }
    } // main
} // class