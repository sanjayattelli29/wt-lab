package com.jpmtechnologies;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class EmpSelect
{
    public static void main(String[] args)
	{
        Session session =null;
        try 
        {
            SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
            session = sessionFactory.openSession();
            Long eno = new Long(101);
            
           /* EmpBean emp = new EmpBean();
            session.load(emp, eno);*/

            EmpBean emp = (EmpBean)session.load(EmpBean.class, eno); //null -> getting data from cache
            //EmpBean emp = (EmpBean)session.get(EmpBean.class, eno); //NullPointerException -> DB

            System.out.println("Employee ID is : " + emp.getId());
            System.out.println("Employee First Name is : " + emp.getFname());
            System.out.println("Employee Last Name is : " + emp.getLname());
            System.out.println("Employee E-Mail is : " + emp.getEmail());
            
            session.close();
        }
        catch (HibernateException e)
        {
            e.printStackTrace();
        }
	} // main
} // class
