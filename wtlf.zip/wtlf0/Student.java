package com.jpmtechnologies.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table()
public class Student {
	@Id
	@Column(name="sid", length=3)
	private int stdId;
	
	@Column(name="sname", length=10)
	private String stdName;
	
	@Column(name="sfee", length=5)
	private double stdFee;
	
	@Column(name="age")
	private int age;
	
	@Column(name="smob")
	private Integer mob;
	
	public Student() {
		super();
	}
	public Student(Integer stdId, String stdName, Double stdFee, Integer age, Integer mob) {
		super();
		this.stdId = stdId;
		this.stdName = stdName;
		this.stdFee = stdFee;
		this.age = age;
		this.mob = mob;
	}
	public int getStdId() {
		return stdId;
	}
	public void setStdId(int stdId) {
		this.stdId = stdId;
	}
	public String getStdName() {
		return stdName;
	}
	public void setStdName(String stdName) {
		this.stdName = stdName;
	}
	public double getStdFee() {
		return stdFee;
	}
	public void setStdFee(double stdFee) {
		this.stdFee = stdFee;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public Integer getMob() {
		return mob;
	}
	public void setMob(Integer mob) {
		this.mob = mob;
	}
	@Override
	public String toString() {
		return "Student [stdId=" + stdId + ", stdName=" + stdName + ", stdFee=" + stdFee + ", Age=" + age + "]";
	}
}
