import java.io.*;
import javax.servlet.*;
public class initparamloginsrv extends GenericServlet
{
public void service(ServletRequest req,ServletResponse res) throws IOException,ServletException
{
res.setContentType("text/html");
PrintWriter out=res.getWriter();
String s1=req.getParameter("uname");
String s2=req.getParameter("pwd");
ServletConfig sc=getServletConfig();
String s3=sc.getInitParameter("uname1");
String s4=sc.getInitParameter("pwd1");
out.println("<h1>UserName:"+s1+"</h1>");
out.println("<h1>Password:"+s2+"</h1>");
out.println("<h1>InitUserName:"+s3+"</h1>");
out.println("<h1>InitPassword:"+s4+"</h1>");
if(s1.equals(s3)&&s2.equals(s4))
out.println("<h1>ValidUser</h1>");
else
out.println("<h1>InValidUser</h1>");
}
}