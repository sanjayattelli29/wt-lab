package com.jpmtechnologies;

//Inserts a record into table.
//www.hibernate.org
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.Session;
import org.hibernate.HibernateException;

public class EmpInsert
{
 public static void main(String args[])
 {
     try
     {
    	 // This step will read hibernate.cfg.xml and prepare hibernate for use
         Configuration conf = new Configuration();
         Configuration cf = conf.configure();
         SessionFactory factory = cf.buildSessionFactory();//Connection pooling.
         Session session = factory.openSession();//Connection

         //Create new instance of Contact and set values in it
         Transaction tx = session.beginTransaction();
         EmpBean emp = new EmpBean();
         emp.setId(101);
         emp.setFname("Abhinav");
         emp.setLname("Sahu");
         emp.setEmail("abhi@gmail.com");
         session.save(emp);//inserting the record into database in the form of object.
         tx.commit();//Save the record into the database
         System.out.println("Record inserted successfully...");
         session.close();
     }
     catch (HibernateException e)
     {
         e.printStackTrace();
     }
 }
}